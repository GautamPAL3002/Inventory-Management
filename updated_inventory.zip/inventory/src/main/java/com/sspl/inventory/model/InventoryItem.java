package com.sspl.inventory.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class InventoryItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String itemName;
    private String ifNo;
    private String crvNo;
    private Integer qty;

    private Double amount;

    private String consumable;
    private String nonConsumable;
    private String nameAllocated;
    private String project;
    private String date;
    private String remark;
}
