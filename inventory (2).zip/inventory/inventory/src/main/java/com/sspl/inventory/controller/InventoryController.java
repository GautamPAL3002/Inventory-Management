package com.sspl.inventory.controller;

import com.sspl.inventory.model.InventoryItem;
import com.sspl.inventory.repository.InventoryRepository;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/api/inventory")
@CrossOrigin(origins = "*")
public class InventoryController {

    @Autowired
    private InventoryRepository inventoryRepository;

    // ✅ GET all items
    @GetMapping
    public List<InventoryItem> getAllItems() {
        return inventoryRepository.findAll();
    }

    // ✅ GET single item by ID
    @GetMapping("/{id}")
    public InventoryItem getItemById(@PathVariable Long id) {
        return inventoryRepository.findById(id).orElse(null);
    }

    // ✅ POST - Add new item
    @PostMapping
    public InventoryItem addItem(@RequestBody InventoryItem item) {
        item.setDate(formatDate(item.getDate()));
        return inventoryRepository.save(item);
    }

    // ✅ PUT - Update existing item
    @PutMapping("/{id}")
    public InventoryItem updateItem(@PathVariable Long id, @RequestBody InventoryItem updatedItem) {
        return inventoryRepository.findById(id)
                .map(item -> {
                    item.setItemName(updatedItem.getItemName());
                    item.setIfNo(updatedItem.getIfNo());
                    item.setCrvNo(updatedItem.getCrvNo());
                    item.setQty(updatedItem.getQty());
                    item.setAmount(updatedItem.getAmount());
                    item.setConsumable(updatedItem.getConsumable());
                    item.setNonConsumable(updatedItem.getNonConsumable());
                    item.setNameAllocated(updatedItem.getNameAllocated());
                    item.setProject(updatedItem.getProject());
                    item.setDate(formatDate(updatedItem.getDate()));
                    item.setRemark(updatedItem.getRemark());
                    return inventoryRepository.save(item);
                })
                .orElse(null);
    }

    // ✅ DELETE
    @DeleteMapping("/{id}")
    public void deleteItem(@PathVariable Long id) {
        inventoryRepository.deleteById(id);
    }

    // ✅ IMPORT Excel
    @PostMapping("/import")
    public ResponseEntity<String> importExcel(@RequestParam("file") MultipartFile file) {
        try (InputStream is = file.getInputStream();
                Workbook workbook = new XSSFWorkbook(is)) {

            Sheet sheet = workbook.getSheetAt(0);
            List<InventoryItem> items = new ArrayList<>();

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null)
                    continue;

                InventoryItem item = new InventoryItem();
                item.setItemName(getCellString(row, 0));
                item.setIfNo(getCellString(row, 1));
                item.setCrvNo(getCellString(row, 2));
                item.setQty((int) getCellNumeric(row, 3));
                item.setAmount(getCellNumeric(row, 4));
                item.setConsumable(getCellString(row, 5));
                item.setNonConsumable(getCellString(row, 6));
                item.setNameAllocated(getCellString(row, 7));
                item.setProject(getCellString(row, 8));
                item.setDate(formatDate(getCellString(row, 9)));
                item.setRemark(getCellString(row, 10));

                items.add(item);
            }

            inventoryRepository.saveAll(items);
            return ResponseEntity.ok("Excel imported successfully!");

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error importing Excel file: " + e.getMessage());
        }
    }

    // ✅ Utility Methods
    private String getCellString(Row row, int index) {
        Cell cell = row.getCell(index);
        if (cell == null)
            return "";
        if (cell.getCellType() == CellType.NUMERIC) {
            if (DateUtil.isCellDateFormatted(cell)) {
                return new SimpleDateFormat("yyyy-MM-dd").format(cell.getDateCellValue());
            } else {
                return String.valueOf((long) cell.getNumericCellValue());
            }
        }
        return cell.toString().trim();
    }

    private double getCellNumeric(Row row, int index) {
        Cell cell = row.getCell(index);
        return (cell != null && cell.getCellType() == CellType.NUMERIC) ? cell.getNumericCellValue() : 0;
    }

    private String formatDate(String date) {
        try {
            if (date == null || date.trim().isEmpty())
                return "";
            SimpleDateFormat parser = new SimpleDateFormat("yyyy-MM-dd");
            Date parsed = parser.parse(date.trim());
            return parser.format(parsed);
        } catch (Exception e) {
            return date;
        }
    }
}
