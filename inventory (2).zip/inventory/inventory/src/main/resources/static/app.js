// ===== GLOBAL STATE =====
let isLoggedIn = false;
let currentPage = null;
let inventoryData = [];
const BASE_URL = "http://localhost:8083/api/inventory";

// ===== ELEMENTS =====
const dashboard = document.querySelector('.dashboard');
const pages = document.querySelectorAll('.page');
const backButtons = document.querySelectorAll('.back-btn');
const loginBtn = document.getElementById('loginBtn');
const loginModal = document.getElementById('loginModal');

const closeLoginModal = document.getElementById('closeLoginModal');
const loginForm = document.getElementById('loginForm');
const itemModal = document.getElementById('itemModal');
const closeItemModal = document.getElementById('closeItemModal');
const itemForm = document.getElementById('itemForm');
const dynamicFormFields = document.querySelector('.dynamicFormFields');
const notification = document.getElementById('notification');

// ===== PAGE BUTTONS =====
document.getElementById('allInventoryBtn').addEventListener('click', () => showPage('allInventoryPage'));
document.getElementById('nameAllocatedBtn').addEventListener('click', () => showPage('nameAllocatedPage'));
document.getElementById('consumableBtn').addEventListener('click', () => showPage('consumablePage'));
document.getElementById('nonConsumableBtn').addEventListener('click', () => showPage('nonConsumablePage'));

// ===== BACK BUTTONS =====
backButtons.forEach(btn => btn.addEventListener('click', () => {
  pages.forEach(p => p.style.display = 'none');
  dashboard.style.display = 'block';
}));

// ===== LOGIN =====
loginBtn.addEventListener('click', () => {
  if (isLoggedIn) {
    isLoggedIn = false;
    loginBtn.textContent = "Login";
    document.querySelectorAll('.adminOnly').forEach(e => e.style.display = 'none');
    showNotification('Logged out successfully!', 'green');
  } else {
    loginModal.style.display = 'flex';
  }
});
closeLoginModal.addEventListener('click', () => loginModal.style.display = 'none');
window.addEventListener('click', e => {
  if (e.target === loginModal) loginModal.style.display = 'none';
  if (e.target === itemModal) itemModal.style.display = 'none';
});

loginForm.addEventListener('submit', e => {
  e.preventDefault();
  const user = document.getElementById('username').value;
  const pass = document.getElementById('password').value;
  if (user && pass) {
    isLoggedIn = true;
    loginBtn.textContent = "Logout";
    document.querySelectorAll('.adminOnly').forEach(e => e.style.display = 'inline-block');
    showNotification('Logged in successfully!', 'green');
    loginModal.style.display = 'none';
    loginForm.reset();
  } else {
    showNotification('Please fill username and password!', 'red');
  }
});

// ===== SHOW PAGE =====
function showPage(id) {
  dashboard.style.display = 'none';
  pages.forEach(p => p.style.display = 'none');
  document.getElementById(id).style.display = 'block';
  currentPage = id;
  loadInventory();
}

// ===== LOAD INVENTORY =====
async function loadInventory() {
  try {
    const res = await fetch(BASE_URL);
    inventoryData = (await res.json()).filter(item => item && item.itemName && item.itemName.trim() !== "");
 renderTable();
  } catch (err) {
    showNotification('Error loading data!', 'red');
    console.error(err);
  }
}

// ===== RENDER TABLE =====
function renderTable() {
  if (!currentPage) return;
  let tbody;
  switch (currentPage) {
    case 'allInventoryPage':
      tbody = document.getElementById('allInventoryBody');
      tbody.innerHTML = '';
      inventoryData

  .forEach((item, i) => {

        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${i + 1}</td>
          <td>${item.itemName}</td>
          <td>${item.ifNo}</td>
          <td>${item.crvNo}</td>
          <td>${item.qty}</td>
          <td>${item.amount}</td>
          <td>${item.consumable}</td>
          <td>${item.nonConsumable}</td>
          <td>${item.nameAllocated}</td>
          <td>${item.project}</td>
          <td>${formatDateForDisplay(item.date)}</td>
          <td>${item.remark || ''}</td>
          

          <td class="adminOnly">
            <button class="action-btn" onclick="openEditModal(${i})">Edit</button>
            <button class="action-btn" onclick="deleteItem(${item.id})">Delete</button>
          </td>`;
        tbody.appendChild(row);
      });
      break;
    case 'nameAllocatedPage':
      tbody = document.getElementById('nameAllocatedBody');
      tbody.innerHTML = '';
      // Show all rows, even if nameAllocated is empty
inventoryData.forEach((item, i) => {
  const row = document.createElement('tr');
  row.innerHTML = `
    <td>${item.nameAllocated || 'N/A'}</td>
    <td>${item.itemName}</td>
    <td>${item.ifNo}</td>
    <td>${item.crvNo}</td>
    <td>${item.qty}</td>
    <td>${item.amount}</td>
    <td class="adminOnly">
      <button class="action-btn" onclick="openEditModal(${i})">Edit</button>
      <button class="action-btn" onclick="deleteItem(${item.id})">Delete</button>
    </td>`;
  tbody.appendChild(row);
});

      break;
    case 'consumablePage':
      tbody = document.getElementById('consumableBody');
      tbody.innerHTML = '';
      inventoryData.filter(x => x.consumable?.toLowerCase() === 'yes').forEach((item, i) => {
        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${item.itemName}</td>
          <td>${item.consumable}</td>
          <td class="adminOnly">
            <button class="action-btn" onclick="openEditModal(${i})">Edit</button>
            <button class="action-btn" onclick="deleteItem(${item.id})">Delete</button>
          </td>`;
        tbody.appendChild(row);
      });
      break;
    case 'nonConsumablePage':
      tbody = document.getElementById('nonConsumableBody');
      tbody.innerHTML = '';
      inventoryData.filter(x => x.nonConsumable?.toLowerCase() === 'yes').forEach((item, i) => {
        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${item.itemName}</td>
          <td>${item.nonConsumable}</td>
          <td class="adminOnly">
            <button class="action-btn" onclick="openEditModal(${i})">Edit</button>
            <button class="action-btn" onclick="deleteItem(${item.id})">Delete</button>
          </td>`;
        tbody.appendChild(row);
      });
      break;
  }
  document.querySelectorAll('.adminOnly').forEach(e => {
    e.style.display = isLoggedIn ? 'inline-block' : 'none';
  });
  bindSearch();
}

// ===== SEARCH =====
function bindSearch() {
  document.querySelectorAll('.search-box').forEach(box => {
    box.addEventListener('input', () => {
      const filter = box.value.toLowerCase();
      const rows = box.parentElement.querySelectorAll('tbody tr');
      rows.forEach(row => {
        row.style.display = [...row.cells].some(cell =>
          cell.textContent.toLowerCase().includes(filter)) ? '' : 'none';
      });
    });
  });
}

// ===== ADD/EDIT ITEM MODAL =====
let editingIndex = null;
document.querySelectorAll('.add-btn').forEach(btn => {
  btn.addEventListener('click', () => openAddModal());
});
document.getElementById('closeItemModal').addEventListener('click', () => {
  itemModal.style.display = 'none';
  editingIndex = null;
  itemForm.reset();
});

function openAddModal() {
  if (!isLoggedIn) {
    showNotification('Login required to add items!', 'red');
    return;
  }
  editingIndex = null;
  document.getElementById('itemModalTitle').textContent = 'Add Item';
  buildFormFields();
  itemModal.style.display = 'flex';
}

function openEditModal(index) {
  if (!isLoggedIn) {
    showNotification('Login required to edit items!', 'red');
    return;
  }
  editingIndex = index;
  document.getElementById('itemModalTitle').textContent = 'Edit Item';
  buildFormFields(inventoryData[index]);
  itemModal.style.display = 'flex';
}

function buildFormFields(data = {}) {
  dynamicFormFields.innerHTML = `
    <div class="form-group"><label>Item Name</label><input type="text" id="formItemName" value="${data.itemName || ''}" required></div>
    <div class="form-group"><label>I/F No</label><input type="text" id="formIfNo" value="${data.ifNo || ''}" required></div>
    <div class="form-group"><label>CRV No</label><input type="text" id="formCrvNo" value="${data.crvNo || ''}" required></div>
    <div class="form-group"><label>Quantity</label><input type="number" id="formQty" value="${data.qty || ''}" required></div>
    <div class="form-group"><label>Amount</label><input type="number" id="formAmount" value="${data.amount || ''}" required></div>
    <div class="form-group"><label>Consumable Item (Yes/No)</label><input type="text" id="formConsumable" value="${data.consumable || ''}" required></div>
    <div class="form-group"><label>Non-Consumable Item (Yes/No)</label><input type="text" id="formNonConsumable" value="${data.nonConsumable || ''}" required></div>
    <div class="form-group"><label>Name Allocated</label><input type="text" id="formNameAllocated" value="${data.nameAllocated || ''}" required></div>
    <div class="form-group"><label>Project Build Up</label><input type="text" id="formProject" value="${data.project || ''}" required></div>
    <div class="form-group"><label>Date</label><input type="date" id="formDate" value="${data.date ? formatDateForInput(data.date) : ''}"></div>
    <div class="form-group"><label>Remark</label><input type="text" id="formRemark" value="${data.remark || ''}"></div>
  `;
}

function formatDateForInput(dateStr) {
  if (!dateStr) return "";
  const parts = dateStr.split("-");
  if (parts.length === 3) {
    // If already yyyy-MM-dd
    return dateStr;
  }
  // If dd-MM-yyyy
  const [dd, mm, yyyy] = dateStr.split("-");
  return `${yyyy}-${mm}-${dd}`;
}
function formatDateForDisplay(dateStr) {
  if (!dateStr) return "";
  if (dateStr.includes("-")) {
    const parts = dateStr.split("-");
    if (parts[0].length === 4) {
      // yyyy-MM-dd => dd-MM-yyyy
      return `${parts[2]}-${parts[1]}-${parts[0]}`;
    }
  }
  return dateStr; // Already dd-MM-yyyy
}



itemForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const newItem = {
    itemName: document.getElementById('formItemName').value,
    ifNo: document.getElementById('formIfNo').value,
    crvNo: document.getElementById('formCrvNo').value,
    qty: parseInt(document.getElementById('formQty').value),
    amount: parseInt(document.getElementById('formAmount').value),
    consumable: document.getElementById('formConsumable').value,
    nonConsumable: document.getElementById('formNonConsumable').value,
    nameAllocated: document.getElementById('formNameAllocated').value,
    project: document.getElementById('formProject').value,
    date: document.getElementById('formDate').value,
    remark: document.getElementById('formRemark').value
  };
  try {
    if (editingIndex !== null) {
      await fetch(`${BASE_URL}/${inventoryData[editingIndex].id}`, {
        method: 'PUT',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(newItem)
      });
      showNotification('Item updated successfully!', 'green');
    } else {
      await fetch(BASE_URL, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(newItem)
      });
      showNotification('Item added successfully!', 'green');
    }
    itemModal.style.display = 'none';
    loadInventory();
  } catch (err) {
    showNotification('Error saving item!', 'red');
  }
});

// ===== DELETE ITEM =====
async function deleteItem(id) {
  if (!isLoggedIn) {
    showNotification('Login required to delete items!', 'red');
    return;
  }
  if (confirm('Are you sure you want to delete this item?')) {
    try {
      await fetch(`${BASE_URL}/${id}`, { method: 'DELETE' });
      showNotification('Item deleted successfully!', 'green');
      loadInventory();
    } catch (err) {
      showNotification('Error deleting item!', 'red');
    }
  }
}

// ===== NOTIFICATION =====
function showNotification(message, color) {
  notification.textContent = message;
  notification.style.background = color;
  notification.classList.add('show');
  setTimeout(() => notification.classList.remove('show'), 2500);
}

// ===== EXCEL IMPORT =====
function importExcel() {
  const fileInput = document.getElementById('excelFileInput');
  const file = fileInput.files[0];
  if (!file) {
    showNotification("Please select an Excel file!", "red");
    return;
  }

  const formData = new FormData();
  formData.append("file", file);

  fetch(`${BASE_URL}/import`, {
    method: 'POST',
    body: formData
  })
    .then(res => res.text())
    .then(msg => {
      showNotification(msg, "green");
      loadInventory();
    })
    .catch(() => showNotification("Import failed!", "red"));
}document.getElementById('exportButton').addEventListener('click', function () {
  const table = document.getElementById('nameAllocatedTable');

  // Check if table exists
  if (!table) {
    alert('Table not found!');
    return;
  }

  // Clone the table (only the visible part)
  const clone = table.cloneNode(true);

  // Remove all rows that are hidden using display:none
  const rows = clone.querySelectorAll('tbody tr');
  rows.forEach(row => {
    const style = window.getComputedStyle(row);
    if (style.display === 'none' || row.hidden) {
      row.remove();
    }
  });

  // Set proper table formatting for PDF
  clone.style.borderCollapse = 'collapse';
  clone.querySelectorAll('th, td').forEach(cell => {
    cell.style.border = '1px solid black';
    cell.style.padding = '6px';
    cell.style.fontSize = '10px';
  });

  // Create a wrapper
  const wrapper = document.createElement('div');
  wrapper.appendChild(clone);

  // Export using html2pdf
  html2pdf()
    .set({
      margin: 0.5,
      filename: 'NameAllocatedData.pdf',
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
    })
    .from(wrapper)
    .save();
});