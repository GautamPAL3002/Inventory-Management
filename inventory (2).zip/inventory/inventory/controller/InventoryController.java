package com.sspl.inventory.controller;

import com.sspl.inventory.model.InventoryItem;
import com.sspl.inventory.repository.InventoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/inventory")
@CrossOrigin(origins = "*")
public class InventoryController {

    @Autowired
    private InventoryRepository inventoryRepository;

    // Get all items
    @GetMapping
    public List<InventoryItem> getAllItems() {
        return inventoryRepository.findAll();
    }

    // Get single item by ID
    @GetMapping("/{id}")
    public InventoryItem getItemById(@PathVariable Long id) {
        return inventoryRepository.findById(id).orElse(null);
    }

    // Add new item
    @PostMapping
    public InventoryItem addItem(@RequestBody InventoryItem item) {
        return inventoryRepository.save(item);
    }

    // Update item
    @PutMapping("/{id}")
    public InventoryItem updateItem(@PathVariable Long id, @RequestBody InventoryItem updatedItem) {
        Optional<InventoryItem> optional = inventoryRepository.findById(id);
        if (optional.isPresent()) {
            InventoryItem item = optional.get();
            item.setItemName(updatedItem.getItemName());
            item.setIfNo(updatedItem.getIfNo());
            item.setCrvNo(updatedItem.getCrvNo());
            item.setQty(updatedItem.getQty());
            item.setAmount(updatedItem.getAmount());
            item.setConsumable(updatedItem.getConsumable());
            item.setNonConsumable(updatedItem.getNonConsumable());
            item.setNameAllocated(updatedItem.getNameAllocated());
            item.setProject(updatedItem.getProject());
            return inventoryRepository.save(item);
        } else {
            return null;
        }
    }

    // Delete item
    @DeleteMapping("/{id}")
    public void deleteItem(@PathVariable Long id) {
        inventoryRepository.deleteById(id);
    }
}
