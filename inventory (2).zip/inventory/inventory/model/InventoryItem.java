@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InventoryItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String itemName;
    private String ifNo;
    private String crvNo;
    private int qty;
    private double amount;
    private String consumable; // ← fixed
    private String nonConsumable; // ← fixed
    private String nameAllocated;
    private String project; // ← fixed
    private String date;
    private String remark;
}
